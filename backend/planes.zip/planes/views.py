import re

from django.shortcuts import render
from .serializers import PlanEntrada
from rest_framework.views import APIView
from rest_framework.response import Response    
from drf_yasg.utils import swagger_auto_schema
from .models import Plan, PlanAgencias


class PlanView(APIView): 
    @swagger_auto_schema(request_body=PlanEntrada)
    def post(self, request):
        nombre = request.data.get('nombre')
        descripcion = request.data.get('descripcion')   
        precio_mensual = request.data.get('precio_mensual')
        precio_trimestral = request.data.get('precio_trimestral')
        precio_anual = request.data.get('precio_anual')
        maximo_agencias = request.data.get('maximo_agencias')   
        maximo_paquetes = request.data.get('maximo_paquetes')
        maximo_buses = request.data.get('maximo_buses')
        maximo_administradores = request.data.get('maximo_administradores')
        id_agencia = request.data.get('id_agencia')
        periodo = request.data.get('periodo')
        vencimiento = request.data.get('vencimiento')
        estado = request.data.get('estado')

        planNuevo = Plan.objects.create(
            nombre=nombre,
            descripcion=descripcion,
            precio_mensual=precio_mensual,
            precio_trimestral=precio_trimestral,
            precio_anual=precio_anual,
            maximo_agencias=maximo_agencias,
            maximo_paquetes=maximo_paquetes,
            maximo_buses=maximo_buses,
            maximo_administradores=maximo_administradores,
            id_agencia=id_agencia,
            periodo=periodo,
            vencimiento=vencimiento,
            estado=estado

        )
        return Response({'message': 'Plan creado exitosamente'})

    @swagger_auto_schema(request_body=PlanEntrada)
    def put(self, request, id):
        plan = Plan.objects.get(id=id)
        plan.nombre = request.data.get('nombre')
        plan.descripcion = request.data.get('descripcion')
        plan.precio_mensual = request.data.get('precio_mensual')
        plan.precio_trimestral = request.data.get('precio_trimestral')
        plan.precio_anual = request.data.get('precio_anual')
        plan.maximo_agencias = request.data.get('maximo_agencias')
        plan.maximo_paquetes = request.data.get('maximo_paquetes')
        plan.maximo_buses = request.data.get('maximo_buses')
        plan.maximo_administradores = request.data.get('maximo_administradores')
        plan.id_agencia = request.data.get('id_agencia')
        plan.periodo = request.data.get('periodo')
        plan.vencimiento = request.data.get('vencimiento')
        plan.estado = request.data.get('estado')
        plan.save()
        return Response({'message': 'Plan actualizado exitosamente'})
